Thanks for downloading Pixaclima 0.1!

===============================================================

To install this to your iPod, first enable Disk Use in the
Finder (or iTunes on older releases of macOS).

Drag the 'pixaclima' folder to the Notes folder (on the iPod
which you should see either in the Finder's sidebar or the Desktop).

Then, on the iPod, open Extras > Notes > pixaclima, then '001
Open Pixaclima'.

===============================================================

Release notes:

*Please* note that this is the very first preview of this project,
and 0.1 is meant to be a bare bones, proof of concept only.

It's really boring. There's not much you can do here other than
play a really short quiz and see a blank screen (in Flashlight).

Plans for the second release (0.2) are to add some preferences
into the shell, better help, and of course some more applets.

Thanks for trying out 0.1! :)